// 1. Creating Arrays
let fruits = ["apple", "banana", "cherry"];
let numbers = [10, 20, 30, 40, 50];

console.log("Fruits:", fruits);
console.log("Numbers:", numbers);

// 2. Accessing and Modifying Elements
console.log("First fruit:", fruits[0]);
fruits[1] = "mango"; // update element
console.log("Updated fruits:", fruits);

// 3. Array Properties
console.log("Length of fruits:", fruits.length);

// 4. Common Array Functions

// push() - add at end
fruits.push("orange");
console.log("After push:", fruits);

// pop() - remove last
fruits.pop();
console.log("After pop:", fruits);

// unshift() - add at start
fruits.unshift("grape");
console.log("After unshift:", fruits);

// shift() - remove first
fruits.shift();
console.log("After shift:", fruits);

// concat() - merge arrays
let moreFruits = ["kiwi", "pear"];
let allFruits = fruits.concat(moreFruits);
console.log("After concat:", allFruits);

// slice() - extract portion
let sliced = allFruits.slice(1, 3);
console.log("Sliced fruits:", sliced);

// splice() - add/remove in middle
allFruits.splice(2, 1, "papaya"); // remove 1 at index 2, add "papaya"
console.log("After splice:", allFruits);

// indexOf() - find index
console.log("Index of cherry:", allFruits.indexOf("cherry"));

// includes() - check if exists
console.log("Contains mango?", allFruits.includes("mango"));

// join() - convert array to string
console.log("Joined fruits:", allFruits.join(" | "));

// reverse()
console.log("Reversed fruits:", [...allFruits].reverse());

// sort()
console.log("Sorted fruits:", [...allFruits].sort());

// 5. Iteration Functions

// forEach()
numbers.forEach((num) => console.log("forEach:", num * 2));

// map()
let squares = numbers.map((n) => n * n);
console.log("Squares (map):", squares);

// filter()
let evens = numbers.filter((n) => n % 2 === 0);
console.log("Even numbers (filter):", evens);

// reduce()
let sum = numbers.reduce((acc, curr) => acc + curr, 0);
console.log("Sum (reduce):", sum);

// find()
let firstBig = numbers.find((n) => n > 25);
console.log("First > 25 (find):", firstBig);

// some()
console.log("Any number > 40?", numbers.some((n) => n > 40));

// every()
console.log("All numbers > 5?", numbers.every((n) => n > 5));
