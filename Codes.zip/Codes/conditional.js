
let year = 2003;

if (year <= 2010 ) {
    console.log("You are GenZ ");
} else if(year > 2010){
    console.log("You are Gen Alpha")
}
else {
    console.log("You are a Millennial ");
}


let day = 3;

switch (day) {
    case 1:
        console.log("Monday");
        break;
    case 2:
        console.log("Tuesday");
        break;
    case 3:
        console.log("Wednesday");
        break;
    default:
        console.log("Other day");
}
