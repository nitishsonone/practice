// Creating an object
let person = {
  name: "Nitish",
  age: 22,
  isStudent: true,
  skills: ["JavaScript", "Python", "Django"],

  // Method inside object
  greet: function () {
    return `Hello, my name is ${this.name}`;
  }
};

// Accessing properties
console.log(person.name);       
console.log(person["age"]);    

// Calling a method
console.log(person.greet());    
// Adding new property
person.city = "Shegaon";
console.log(person.city);       

// Updating existing property
person.age = 23;
console.log(person.age);        

// Deleting a property
delete person.isStudent;
console.log(person.isStudent);  

// Nested object
person.address = {
  street: "SSGMCE",
  pincode: 444203
};
console.log(person.address.street); 

// Iterating over object keys
for (let key in person) {
  console.log(`${key} : ${person[key]}`);
}

// Object methods
console.log(Object.keys(person));   
console.log(Object.values(person)); 