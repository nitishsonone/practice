
var name = "Alice";
console.log(name); 
name = "Bob"; 
console.log(name); 


let age = 20;
console.log(age); 
age = 25;
console.log(age); 


const country = "India";
console.log(country); 



//var scope issue

if (true) {
    var x = 10;  
}
console.log(x); 


if (true) {
    let y = 20;  
}
console.log(y); 


