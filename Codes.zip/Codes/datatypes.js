
let name = "Apexaiq";
console.log(typeof name);  


let year = 2;
console.log(typeof year);   


let isStudent = true;
console.log(typeof isStudent);  


let emptyValue = null;
console.log(typeof emptyValue); 


let notAssigned;
console.log(typeof notAssigned); 


let person = { firstName: "Nitish", lastName: "Sonone" };
console.log(typeof person); 


let fruits = ["Apple", "Banana", "Mango"];
console.log(typeof fruits);          
console.log(Array.isArray(fruits));  
