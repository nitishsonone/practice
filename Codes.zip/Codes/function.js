// 1. Function Declaration (Named Function)
function greet() {
    console.log("Hello Interns");
}
greet();

// 2. Function Expression (Anonymous Function stored in a variable)
const sayHi = function() {
    console.log("Hello Interns");
};
sayHi();

// 3. Arrow Function (ES6+)
const arrowGreet = () => {
    console.log("Hello from Arrow Function");
};
arrowGreet();

// 4. Arrow Function (with single-line return)
const add = (a, b) => a + b;
console.log("Addition (Arrow Function):", add(5, 3));

// 5. Anonymous Function (used directly, e.g., setTimeout)
setTimeout(function() {
    console.log("Hello from Anonymous Function inside setTimeout!");
}, 500);

// 6. IIFE - Immediately Invoked Function Expression
(function() {
    console.log("Hello from IIFE!");
})();

// 7. Higher-Order Function (function passed as argument)
function operate(num, fn) {
    return fn(num);
}
const double = (n) => n * 2;
console.log("Higher Order Function Result:", operate(5, double));

// 8. Callback Function Example
function fetchData(callback) {
    console.log("Fetching data...");
    callback("Data received!");
}
fetchData((message) => console.log(message));
