
console.log("FOR Loop:");
for (let i = 1; i <= 5; i++) {
    console.log("Iteration:", i);
}


console.log("\nWHILE Loop:");
let count = 1;
while (count <= 5) {
    console.log("Count:", count);
    count++;
}


console.log("\nDO-WHILE Loop:");
let num = 1;
do {
    console.log("Number:", num);
    num++;
} while (num <= 5);


console.log("\nFOR...OF Loop:");
let fruits = ["Apple", "Banana", "Cherry"];
for (let fruit of fruits) {
    console.log("Fruit:", fruit);
}


console.log("\nFOR...IN Loop:");
let person = { name: "Nitish", age: 22, city: "Pune" };
for (let key in person) {
    console.log(key, ":", person[key]);
}
